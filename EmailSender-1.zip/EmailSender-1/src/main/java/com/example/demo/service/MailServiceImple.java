package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Userinfo;
import com.example.demo.repo.MailRepo;

@Service
public class MailServiceImple implements MailService {
	@Autowired
	MailRepo repo;

	@Autowired
	JavaMailSender javaMailSender;

	Map<Integer, Userinfo> map = new HashMap<>();

	@Override
	public void sendMail(Userinfo userinfo) {

		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(userinfo.getEmail());
		msg.setSubject("Hello");

		msg.setText(userinfo.getName());

		javaMailSender.send(msg);
		Userinfo save = repo.save(userinfo);
		map.put(save.getId(), save);
	}

	@Override
	public List<Userinfo> getCache() {
		return new ArrayList<>(map.values());
	}

}
