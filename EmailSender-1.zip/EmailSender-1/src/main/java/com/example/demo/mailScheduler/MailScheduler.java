package com.example.demo.mailScheduler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.example.demo.entity.Userinfo;
import com.example.demo.service.MailService;

@Component
public class MailScheduler {

	@Autowired
	MailService mailService;

	@Scheduled(cron = "* * * * * ? *")
	public void sendMails() {
		List<Userinfo> user = mailService.getCache();
		for (Userinfo userinfo : user) {
			mailService.sendMail(userinfo);

		}
	}

}
