package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Userinfo;
import com.example.demo.service.MailService;

@RestController
@RequestMapping("/mail")
public class MailController {

	@Autowired
	MailService mailService;

	@PostMapping("/send")
	public String sendMail(@RequestBody Userinfo userinfo) {

		mailService.sendMail(userinfo);

		return "mail is send Succesfully " + userinfo.getEmail();

	}

	@GetMapping("/users")
	public List<Userinfo> getCache() {

		return mailService.getCache();

	}

}
