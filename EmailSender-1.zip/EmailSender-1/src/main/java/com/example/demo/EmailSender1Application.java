package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmailSender1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmailSender1Application.class, args);
	}

}
