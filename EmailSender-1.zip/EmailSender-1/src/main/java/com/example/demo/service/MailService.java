package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Userinfo;

public interface MailService {

	void sendMail(Userinfo userinfo);

	List<Userinfo> getCache();

}
